package com.example.appasia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Cadastrar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
}
